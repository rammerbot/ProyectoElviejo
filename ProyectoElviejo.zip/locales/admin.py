from django.contrib import admin
from .models import Local

admin.site.register(Local)

# Register your models here.
